<?php
$servername = "localhost";
$username = "your_username"; // Укажите имя пользователя вашей БД
$password = "your_password"; // Укажите пароль вашего пользователя
$dbname = "shop"; // Имя вашей базы данных

// Устанавливаем соединение с базой данных
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем наличие ошибок при соединении
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>