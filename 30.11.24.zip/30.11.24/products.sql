CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    category VARCHAR(100),
    price DECIMAL(10, 2)
);

INSERT INTO products (name, category, price) VALUES
('iPhone', 'Electronics', 70000.00),
('T-Shirt', 'Clothing', 1500.00),
('Chair', 'Furniture', 5000.00),
('Sony TV', 'Electronics', 45000.00),
('Jeans', 'Clothing', 2500.00);