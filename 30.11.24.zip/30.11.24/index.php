<html>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
    <meta charset="UTF-8">
    <title>Фильтрация товаров</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        input[type="number"],
        input[type="text"],
        select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        input[type="submit"], button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button:hover, input[type="submit"]:hover {
            background-color: #45a049;
        }
        
        form {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
    </head>
    <body>
    
        <h1>Каталог товаров</h1>

        <!-- Форма для фильтрации -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="category">Категория:</label>
            <select id="category" name="category">
                <option value="">Все</option>
                <?php
                    include 'db.php';
                    $categories = array();
                    $result = $conn->query("SELECT DISTINCT category FROM products");
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $categories[] = $row['category'];
                        }
                    }
                    foreach ($categories as $cat) {
                        echo "<option value='$cat'>$cat</option>";
                    }
                ?>
            </select>

            <label for="min_price">Минимальная цена:</label>
            <input type="number" id="min_price" name="min_price" placeholder="Введите минимальную цену">

            <label for="max_price">Максимальная цена:</label>
            <input type="number" id="max_price" name="max_price" placeholder="Введите максимальную цену">

            <label for="search_name">Название товара:</label>
            <input type="text" id="search_name" name="search_name" placeholder="Введите название товара">

            <button type="submit">Применить фильтр</button>
        </form>

        <!-- Таблица для вывода товаров -->
        <table>
            <tr>
                <th>ID</th>
                <th>Название</th>
                <th>Категория</th>
                <th>Цена</th>
            </tr>
            <?php
                include 'db.php';
        
                // Получение фильтров из формы
                $category = isset($_POST['category']) ? $_POST['category'] : '';
                $min_price = isset($_POST['min_price']) ? (float)$_POST['min_price'] : 0;
                $max_price = isset($_POST['max_price']) ? (float)$_POST['max_price'] : PHP_INT_MAX;
                $search_name = isset($_POST['search_name']) ? $_POST['search_name'] : '';
        
                // Формирование SQL-запроса с учетом фильтров
                $sql = "SELECT * FROM products WHERE price BETWEEN ? AND ?";
                
                // Добавление фильтра по категории, если он задан
                if ($category) {
                    $sql .= " AND category = ?";
                }
                
                // Добавление фильтра по названию товара, если он задан
                if ($search_name) {
                    $sql .= " AND name LIKE ?";
                }
        
                // Подготовка запроса
                $stmt = $conn->prepare($sql);
                
                // Определение параметров для запроса
                if ($search_name) {
                    $search_name = '%' . $search_name . '%'; // Для поиска по частичному совпадению
                    if ($category) {
                        $stmt->bind_param("dds", $min_price, $max_price, $category);
                        $stmt->bind_param("dss", $min_price, $max_price, $search_name);
                    } else {
                        $stmt->bind_param("ds", $min_price, $max_price);
                        $stmt->bind_param("ss", $min_price, $max_price, $search_name);
                    }
                } else {
                    if ($category) {
                        $stmt->bind_param("ds", $min_price, $max_price);
                        $stmt->bind_param("s", $category);
                    } else {
                        $stmt->bind_param("dd", $min_price, $max_price);
                    }
                }
        
                // Выполнение запроса
                if ($stmt->execute()) {
                    // Получение результата
                    $result = $stmt->get_result();
                    
                    // Вывод данных в таблицу
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["category"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["price"]) . " руб.</td>";
                        echo "</tr>";
                    }
                    
                    // Освобождение результата
                    $result->free();
                } else {
                    echo "Ошибка: " . htmlspecialchars($conn->error);
                }
        
                // Закрытие соединения
                $stmt->close();
            ?>
        </table>
    </body>
</html>
